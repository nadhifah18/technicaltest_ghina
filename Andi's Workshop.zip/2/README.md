# Ketentuan Jawaban

## Buatlah database menggunakan PostgreSQL berdasarkan ER Diagram anda

Upload SQL File anda disini
