
# Ketentuan Jawaban

## [OPTIONAL] Buatlah program untuk bulk insert ke sistem memakai CSV

Bebas menggunakan bahasa pemograman apapun

- Project file anda disini
- Sertakan screenshot-screenshot hasil