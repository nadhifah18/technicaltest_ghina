
# Ketentuan Jawaban

## Sebutkan anomali-anomali data yang ada di data tersebut dan cara anda untuk memperbaiki data tersebut 

- Sebutkan anomali anomali data yang ada di file 'ANSWER.md'
- Sertakan Jawaban dan SQL File

contoh jawaban ada di [ANSWER.md](ANSWER.md)