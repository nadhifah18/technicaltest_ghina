
# Ketentuan Jawaban

## [OPTIONAL] Buatlah visualisasi statistik pelaporan harian

Bebas menggunakan bahasa pemograman apapun

- Project file anda disini
- Sertakan screenshot-screenshot hasil
