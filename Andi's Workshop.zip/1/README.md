# Ketentuan Jawaban

## Buatkan ER Diagram untuk sistem database yang dibutuhkan oleh Andi

Upload ER Diagram anda di folder ini
