# Ketentuan Jawaban

## Buatlah SQL Query untuk menampilkan apa yang dibutuhkan Andi

Upload SQL File anda disini
