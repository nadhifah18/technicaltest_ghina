
# Ketentuan Jawaban

## Buatlah SQL Query untuk mengubah data 

- Upload SQL File anda disini