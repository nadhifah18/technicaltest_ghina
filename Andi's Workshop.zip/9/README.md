
# Ketentuan Jawaban

## [OPTIONAL] buatlah program yang dapat memvisualisasikan apa yang dibutuhkan Andi (table, statistik, dan filtering) [VIEW ONLY]

Bebas menggunakan bahasa pemograman apapun

- Project file anda disini
- Sertakan screenshot-screenshot hasil