
# Ketentuan Jawaban

## Buatlah SQL Query untuk memasukan data berdasarkan dari csv yang sudah diberikan 

- Upload SQL File anda disini
- Upload Screenshot hasil data anda disini
- Upload Hasil data anda berdasarkan Query yang sudah anda buat di nomor 3